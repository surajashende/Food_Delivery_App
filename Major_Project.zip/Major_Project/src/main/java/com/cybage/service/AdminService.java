package com.cybage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entities.Admin;
import com.cybage.entities.Rest_Owner;
import com.cybage.repository.AdminRepository;
import com.cybage.repository.Rest_OwnerRepository;

@Service
public class AdminService {

@Autowired
AdminRepository adminrepo;


	public Admin adminLogin(String email,String password)
	{
		
		return adminrepo.findByEmailandPassword(email, password);
	}
	
	



}
