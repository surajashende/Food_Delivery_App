package com.cybage.entities;

import java.util.List;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Component
@Table(name="category")
public class Category {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cat_id")
	private Integer id;
	@Column(length = 20)
	private String cat_name;
	

	 @OneToMany(mappedBy ="category")
	 @JsonIgnore
	    private List<Product> product;
	 
	 @ManyToOne(fetch = FetchType.LAZY,
	            cascade = {
	                    CascadeType.MERGE,
	                    CascadeType.PERSIST
	                })
	 @JsonIgnore
	    @JoinColumn(name = "owner_id")
	    private Rest_Owner restowner;
	 
	 

	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Category(String cat_name, List<Product> product, Rest_Owner restowner) {
		super();
		this.cat_name = cat_name;
		this.product = product;
		this.restowner = restowner;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCat_name() {
		return cat_name;
	}

	public void setCat_name(String cat_name) {
		this.cat_name = cat_name;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public Rest_Owner getRestowner() {
		return restowner;
	}

	public void setRestowner(Rest_Owner restowner) {
		this.restowner = restowner;
	}

	@Override
	public String toString() {
		return "Category [id=" + id + ", cat_name=" + cat_name + ", product=" + product + ", restowner=" + restowner
				+ "]";
	}
	 
	 

}
