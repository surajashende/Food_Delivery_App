package com.cybage.entities;

public enum Role {
	ADMIN,USER,RESTAURANT_OWNER;

}
