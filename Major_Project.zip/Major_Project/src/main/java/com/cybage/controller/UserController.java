package com.cybage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cybage.entities.User;

import com.cybage.service.UserService;


@RestController
@EnableAutoConfiguration
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {
	
	@Autowired
	UserService userservice;
	
	@PutMapping("/update/{id}")
	public ResponseEntity<?> updateUserDetails(@RequestBody User detacheduser,@PathVariable("id") int userId){
		//check if user exit by id
	//	rest_ownerservice.getOwnerById(detachedOwner.getId());
		return ResponseEntity.ok(userservice.updateUserDetails(detacheduser,userId));
	}
	@DeleteMapping("/{userId}")
	public ResponseEntity<String> deleteuserDetails(@PathVariable int userId){
		System.out.println("in del user Details "+userId);
		return ResponseEntity.ok(userservice.deleteuserDetails(userId));
	}
	
}
