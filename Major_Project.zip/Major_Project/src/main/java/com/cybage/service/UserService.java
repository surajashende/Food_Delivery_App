package com.cybage.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cybage.entities.Rest_Owner;
import com.cybage.entities.User;
import com.cybage.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	  private UserRepository userrepo;

public User updateUserDetails(User user,int userId) {
		
	User user1=userrepo.getUserById(userId);
		//if(rest_owner.getRole().equals(Role.RESTAURANT_OWNER)) {
		
	user1.setName(user.getName());
	user1.setAddress(user.getAddress());
	user1.setEmail(user.getEmail());
	user1.setPhoneNo(user.getPhoneNo());
	user1.setPassword(user.getPassword());
	user1.setArea(user.getArea());
	user1.setCity(user.getCity());
	user1.setPincode(user.getPincode());
			User userDetails = userrepo.save(user1);
		return userDetails;
	}


public String deleteuserDetails(int userId) {
		
	userrepo.deleteById(userId);
		return "User details deleted successfully with id : "+userId;
	}
}
