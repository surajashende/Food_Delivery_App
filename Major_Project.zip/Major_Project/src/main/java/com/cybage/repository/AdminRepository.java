package com.cybage.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.cybage.entities.Admin;


@Repository
@EnableJpaRepositories
public interface AdminRepository extends JpaRepository<Admin,Integer> {
	
	@Query("select a from Admin a where a.email =:email and a.password =:password")
   	Admin findByEmailandPassword(String email,String password);


}
