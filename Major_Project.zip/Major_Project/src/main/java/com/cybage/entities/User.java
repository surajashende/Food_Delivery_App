package com.cybage.entities;

import java.sql.Time;
import java.util.List;

import javax.persistence.*;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="user")
public class User {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private int id;
	@Column(length = 20, nullable = false)
	private String password;
	@Column(name="email_id",unique = true, nullable = false)
	private String email;
	@Column(length=20,nullable = false)
	private Role role;
	@Column(length = 20,nullable = false)
	private String name;
	@Column(length = 50,nullable = false)
	private String phoneNo;
	@Column(length = 50,nullable = false)
	private String address;
	@Column(length = 50,nullable = false)
	private String area;
	@Column(length = 50,nullable = false)
	private String city;
	@Column(length = 50,nullable = false)
	private String pincode;
	@Column(length = 50,nullable = false)
	private String one_time_password;
	
private static final long OTP_VALID_DURATION = 5 * 60 * 1000;

	@Column(length = 50,nullable = false)
	private Time otp_requested_time;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User( String password, String email, Role role, String name, String phoneNo, String address,
			String area, String city, String pincode) {
		super();
		this.password = password;
		this.email = email;
		this.role = role;
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
	}
	
	
	public User(String password, String email, Role role, String name, String phoneNo, String address, String area,
			String city, String pincode, String one_time_password, Time otp_requested_time) {
		super();
		this.password = password;
		this.email = email;
		this.role = role;
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
		this.area = area;
		this.city = city;
		this.pincode = pincode;
		this.one_time_password = one_time_password;
		this.otp_requested_time = otp_requested_time;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getOne_time_password() {
		return one_time_password;
	}
	public void setOne_time_password(String one_time_password) {
		this.one_time_password = one_time_password;
	}
	public Time getOtp_requested_time() {
		return otp_requested_time;
	}
	public void setOtp_requested_time(Time otp_requested_time) {
		this.otp_requested_time = otp_requested_time;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", password=" + password + ", email=" + email + ", role=" + role + ", name=" + name
				+ ", phoneNo=" + phoneNo + ", address=" + address + ", area=" + area + ", city=" + city + ", pincode="
				+ pincode + ", one_time_password=" + one_time_password + ", otp_requested_time=" + otp_requested_time
				+ "]";
	}
	 public boolean isOTPRequired() {
	        if (this.getOne_time_password() == null) {
	            return false;
	        }
	         
	        long currentTimeInMillis = System.currentTimeMillis();
	        long otpRequestedTimeInMillis = this.otp_requested_time.getTime();
	         
	        if (otpRequestedTimeInMillis + OTP_VALID_DURATION < currentTimeInMillis) {
	            // OTP expires
	            return false;
	        }
	         
	        return true;
	    }

	 
	

}
