package com.cybage.entities;

import java.util.List;

import javax.persistence.*;

import org.springframework.stereotype.Component;

@Entity
@Table(name="rest_owner")
@Component
public class Rest_Owner {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "owner_id")
	private Integer id;
	@Column(length = 20)
	private String password;
	@Column(name="email_id",unique = true)
	private String email;
	@Column(length=20)
	private Role role;
	@Column(length = 20)
	private String name;
	@Column(length = 10)
	private String phoneNo;

	 @OneToMany(mappedBy ="rest_owner1")
	 
	    private List<Restaurant> restaurant;

	 @OneToMany(mappedBy ="rest_owner")
	 
	    private List<Product> product;
	 

	 @OneToMany(mappedBy ="restowner")
	 
	    private List<Category> category;
	 
	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id")
    private Admin admin;
 
	public Rest_Owner() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Rest_Owner(String password, String email, Role role, String name, String phoneNo,
			List<Restaurant> restaurant, List<Product> product, List<Category> category, Admin admin) {
		super();
		this.password = password;
		this.email = email;
		this.role = role;
		this.name = name;
		this.phoneNo = phoneNo;
		this.restaurant = restaurant;
		this.product = product;
		this.category = category;
		this.admin = admin;
	}

	public Integer getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public List<Restaurant> getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(List<Restaurant> restaurant) {
		this.restaurant = restaurant;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public List<Category> getCategory() {
		return category;
	}

	public void setCategory(List<Category> category) {
		this.category = category;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "Rest_Owner [owner_id=" + id + ", password=" + password + ", email=" + email + ", role=" + role
				+ ", name=" + name + ", phoneNo=" + phoneNo + ", restaurant=" + restaurant + ", product=" + product
				+ ", category=" + category + ", admin=" + admin + "]";
	}

	

}
