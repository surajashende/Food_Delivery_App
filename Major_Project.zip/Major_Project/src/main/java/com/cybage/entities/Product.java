package com.cybage.entities;

import javax.persistence.*;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Component
@Table(name="product")
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "product_id")
	private Integer id;
	@Column(length = 20)
	private String product_name;
	@Column(length = 20)
	private String product_price;	
	@ManyToOne(cascade = CascadeType.ALL)
	//@JsonIgnore
    @JoinColumn(name = "cat_id")
    private Category category;
	
	@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	//@JsonIgnore
   @JoinColumn(name = "owner_id")
    private Rest_Owner rest_owner;
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(String product_name, String product_price, Category category, Rest_Owner rest_owner) {
		super();
		this.product_name = product_name;
		this.product_price = product_price;
		this.category = category;
		this.rest_owner = rest_owner;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_price() {
		return product_price;
	}

	public void setProduct_price(String product_price) {
		this.product_price = product_price;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Rest_Owner getRest_owner() {
		return rest_owner;
	}

	public void setRest_owner(Rest_Owner rest_owner) {
		this.rest_owner = rest_owner;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", product_name=" + product_name + ", product_price=" + product_price
				+ ", category=" + category + ", rest_owner=" + rest_owner + "]";
	}
	

}
